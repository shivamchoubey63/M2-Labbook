import { Mobile } from "./mobile";

class BasicPhone extends Mobile {
    mobileType:string;
}