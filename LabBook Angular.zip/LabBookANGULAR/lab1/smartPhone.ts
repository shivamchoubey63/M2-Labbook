import { Mobile } from "./mobile";

class SmartPhone extends Mobile{
    mobileType:string;
}